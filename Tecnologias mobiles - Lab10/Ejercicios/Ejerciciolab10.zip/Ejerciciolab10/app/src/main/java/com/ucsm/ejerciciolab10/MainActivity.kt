package com.ucsm.ejerciciolab10

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private lateinit var tvDisplay: TextView
    private var firstNum: Double = 0.0
    private var operator: String = ""
    private var isNewOp: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        tvDisplay = findViewById(R.id.tvDisplay)

        val buttons = listOf(
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9, R.id.btnDot
        )

        for (id in buttons) {
            findViewById<Button>(id).setOnClickListener { onNumberClick(it as Button) }
        }

        findViewById<Button>(R.id.btnAdd).setOnClickListener { onOperatorClick("+") }
        findViewById<Button>(R.id.btnMinus).setOnClickListener { onOperatorClick("-") }
        findViewById<Button>(R.id.btnMult).setOnClickListener { onOperatorClick("*") }
        findViewById<Button>(R.id.btnDiv).setOnClickListener { onOperatorClick("/") }
        findViewById<Button>(R.id.btnPower).setOnClickListener { onOperatorClick("^") }

        findViewById<Button>(R.id.btnSqrt).setOnClickListener {
            val num = tvDisplay.text.toString().toDoubleOrNull() ?: 0.0
            if (num >= 0) {
                val result = sqrt(num)
                tvDisplay.text = formatResult(result)
                isNewOp = true
            } else {
                tvDisplay.text = "Error"
            }
        }

        findViewById<Button>(R.id.btnC).setOnClickListener {
            tvDisplay.text = "0"
            firstNum = 0.0
            operator = ""
            isNewOp = true
        }

        findViewById<Button>(R.id.btnEqual).setOnClickListener {
            val secondNum = tvDisplay.text.toString().toDoubleOrNull() ?: 0.0
            var result = 0.0
            when (operator) {
                "+" -> result = firstNum + secondNum
                "-" -> result = firstNum - secondNum
                "*" -> result = firstNum * secondNum
                "/" -> result = if (secondNum != 0.0) firstNum / secondNum else Double.NaN
                "^" -> result = firstNum.pow(secondNum)
            }
            tvDisplay.text = if (result.isNaN()) "Error" else formatResult(result)
            isNewOp = true
        }
    }

    private fun onNumberClick(button: Button) {
        if (isNewOp) {
            tvDisplay.text = ""
            isNewOp = false
        }
        val currentText = tvDisplay.text.toString()
        val btnText = button.text.toString()

        if (btnText == "." && currentText.contains(".")) return
        
        tvDisplay.append(btnText)
    }

    private fun onOperatorClick(op: String) {
        firstNum = tvDisplay.text.toString().toDoubleOrNull() ?: 0.0
        operator = op
        isNewOp = true
    }

    private fun formatResult(result: Double): String {
        return if (result == result.toLong().toDouble()) {
            result.toLong().toString()
        } else {
            result.toString()
        }
    }
}
