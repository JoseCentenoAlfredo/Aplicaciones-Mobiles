package com.ucsm.laboratorio06actividadb

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val tilNombre = findViewById<TextInputLayout>(R.id.tilNombre)
        val etNombre = findViewById<TextInputEditText>(R.id.etNombre)


        etNombre.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val texto = etNombre.text.toString()
                if (texto.isEmpty()) {
                    tilNombre.error = "El nombre es obligatorio"
                } else if (texto.length > 8) {
                    tilNombre.error = "No puede exceder los 8 caracteres"
                } else {
                    tilNombre.error = null // Limpiar error
                }
            }
        }
    }
}