package com.ucsm.laboratorio06actividadc

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Habilitar Edge-to-Edge para Material 3
        enableEdgeToEdge()
        
        setContentView(R.layout.activity_main)

        // Configurar padding para evitar que la UI quede bajo las barras del sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Simular autofocus: true del TextField de Flutter
        val editText = findViewById<TextInputEditText>(R.id.editText)
        editText.requestFocus()
    }
}
