package com.ucsm.lab6ejercicios

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Manejo de Insets para Material 3 / Edge-to-Edge
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Referencias a las vistas
        val yearInputLayout = findViewById<TextInputLayout>(R.id.yearInputLayout)
        val yearEditText = findViewById<TextInputEditText>(R.id.yearEditText)
        val calculateButton = findViewById<MaterialButton>(R.id.calculateButton)
        val resultCard = findViewById<MaterialCardView>(R.id.resultCard)
        val resultText = findViewById<TextView>(R.id.resultText)

        // Lógica de cálculo
        calculateButton.setOnClickListener {
            val texto = yearEditText.text.toString().trim()
            val anio = texto.toIntOrNull()
            val anioActual = Calendar.getInstance().get(Calendar.YEAR)

            if (anio == null) {
                yearInputLayout.error = getString(R.string.error_invalid_year)
                resultCard.visibility = View.GONE
            } else if (anio < 1900 || anio > anioActual) {
                yearInputLayout.error = getString(R.string.error_year_range, anioActual)
                resultCard.visibility = View.GONE
            } else {
                // Éxito: limpiar error y mostrar resultado
                yearInputLayout.error = null
                val edad = anioActual - anio
                resultText.text = getString(R.string.result_format, edad)
                resultCard.visibility = View.VISIBLE
            }
        }
    }
}
