package com.norbel.ejercicio_lab5

data class Product(
    val name: String,
    val quantity: Int,
    val price: Double
)
