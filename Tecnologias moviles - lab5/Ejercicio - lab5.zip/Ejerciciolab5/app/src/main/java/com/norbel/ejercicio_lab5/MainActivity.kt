package com.norbel.ejercicio_lab5

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var etName: EditText
    private lateinit var etQuantity: EditText
    private lateinit var etPrice: EditText
    private lateinit var btnAdd: Button
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ProductAdapter
    private val productList = mutableListOf<Product>()

    private val sharedPrefs by lazy { getSharedPreferences("products_prefs", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initViews()
        loadProducts()
        setupRecyclerView()

        btnAdd.setOnClickListener {
            addProduct()
        }
    }

    private fun initViews() {
        etName = findViewById(R.id.etName)
        etQuantity = findViewById(R.id.etQuantity)
        etPrice = findViewById(R.id.etPrice)
        btnAdd = findViewById(R.id.btnAdd)
        recyclerView = findViewById(R.id.recyclerView)
    }

    private fun setupRecyclerView() {
        adapter = ProductAdapter(productList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun addProduct() {
        val name = etName.text.toString()
        val quantityStr = etQuantity.text.toString()
        val priceStr = etPrice.text.toString()

        if (name.isNotEmpty() && quantityStr.isNotEmpty() && priceStr.isNotEmpty()) {
            val quantity = quantityStr.toInt()
            val price = priceStr.toDouble()
            val product = Product(name, quantity, price)
            
            productList.add(product)
            saveProducts()
            adapter.notifyItemInserted(productList.size - 1)
            
            // Clear inputs
            etName.text.clear()
            etQuantity.text.clear()
            etPrice.text.clear()
        } else {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveProducts() {
        val jsonArray = JSONArray()
        for (product in productList) {
            val jsonObject = JSONObject()
            jsonObject.put("name", product.name)
            jsonObject.put("quantity", product.quantity)
            jsonObject.put("price", product.price)
            jsonArray.put(jsonObject)
        }
        sharedPrefs.edit().putString("product_list", jsonArray.toString()).apply()
    }

    private fun loadProducts() {
        val jsonString = sharedPrefs.getString("product_list", null)
        if (jsonString != null) {
            val jsonArray = JSONArray(jsonString)
            productList.clear()
            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                val name = jsonObject.getString("name")
                val quantity = jsonObject.getInt("quantity")
                val price = jsonObject.getDouble("price")
                productList.add(Product(name, quantity, price))
            }
        }
    }
}
