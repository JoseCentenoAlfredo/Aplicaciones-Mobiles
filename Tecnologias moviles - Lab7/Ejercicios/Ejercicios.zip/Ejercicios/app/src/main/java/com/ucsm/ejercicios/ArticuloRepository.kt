package com.ucsm.ejercicios

import kotlinx.coroutines.flow.Flow

class ArticuloRepository(private val articuloDao: ArticuloDao) {
    val todosLosArticulos: Flow<List<Articulo>> = articuloDao.listarTodos()

    suspend fun insertar(articulo: Articulo) {
        articuloDao.insertar(articulo)
    }

    suspend fun actualizar(articulo: Articulo) {
        articuloDao.actualizar(articulo)
    }

    suspend fun eliminar(articulo: Articulo) {
        articuloDao.eliminar(articulo)
    }
}
