package com.ucsm.ejercicios

import androidx.lifecycle.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class ArticuloViewModel(private val repository: ArticuloRepository) : ViewModel() {

    val todosLosArticulos: Flow<List<Articulo>> = repository.todosLosArticulos

    fun insertar(articulo: Articulo) = viewModelScope.launch {
        repository.insertar(articulo)
    }

    fun actualizar(articulo: Articulo) = viewModelScope.launch {
        repository.actualizar(articulo)
    }

    fun eliminar(articulo: Articulo) = viewModelScope.launch {
        repository.eliminar(articulo)
    }
}

class ArticuloViewModelFactory(private val repository: ArticuloRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ArticuloViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ArticuloViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
