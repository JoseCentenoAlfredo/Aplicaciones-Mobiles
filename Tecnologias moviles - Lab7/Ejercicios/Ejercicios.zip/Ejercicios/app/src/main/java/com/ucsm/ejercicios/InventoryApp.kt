package com.ucsm.ejercicios

import android.app.Application

class InventoryApp : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { ArticuloRepository(database.articuloDao()) }
}
