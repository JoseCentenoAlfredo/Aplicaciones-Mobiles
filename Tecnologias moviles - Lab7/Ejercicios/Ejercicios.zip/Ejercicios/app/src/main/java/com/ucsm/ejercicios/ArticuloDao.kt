package com.ucsm.ejercicios

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ArticuloDao {
    @Query("SELECT * FROM articulos")
    fun listarTodos(): Flow<List<Articulo>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertar(articulo: Articulo)

    @Update
    suspend fun actualizar(articulo: Articulo)

    @Delete
    suspend fun eliminar(articulo: Articulo)
}
