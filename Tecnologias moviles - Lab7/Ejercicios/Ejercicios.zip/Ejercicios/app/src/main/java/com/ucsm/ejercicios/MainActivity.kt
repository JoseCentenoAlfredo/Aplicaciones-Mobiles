package com.ucsm.ejercicios

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private val viewModel: ArticuloViewModel by viewModels {
        ArticuloViewModelFactory((application as InventoryApp).repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnInsertar = findViewById<Button>(R.id.btnInsertar)
        val btnExportar = findViewById<Button>(R.id.btnExportar)
        val tvArticulos = findViewById<TextView>(R.id.tvArticulos)

        btnInsertar.setOnClickListener {
            val nuevoArticulo = Articulo(
                nombre = "Articulo ${System.currentTimeMillis() % 1000}",
                cantidad = (1..100).random(),
                precio = (10..500).random().toDouble()
            )
            viewModel.insertar(nuevoArticulo)
        }

        btnExportar.setOnClickListener {
            exportarInventarioAExterno()
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.todosLosArticulos.collect { lista ->
                    val texto = lista.joinToString("\n") { 
                        "ID: ${it.id} | ${it.nombre} - Cant: ${it.cantidad} - $${it.precio}" 
                    }
                    tvArticulos.text = if (lista.isEmpty()) "Inventario vacío" else texto
                }
            }
        }
    }

    private fun exportarInventarioAExterno() {
        lifecycleScope.launch {
            val lista = viewModel.todosLosArticulos.first()
            if (lista.isEmpty()) {
                Toast.makeText(this@MainActivity, "No hay datos para exportar", Toast.LENGTH_SHORT).show()
                return@launch
            }

            val contenido = lista.joinToString("\n") { "${it.id},${it.nombre},${it.cantidad},${it.precio}" }
            val directorio = getExternalFilesDir("exports")
            val archivo = File(directorio, "inventario_respaldo.csv")

            try {
                FileOutputStream(archivo).use { output ->
                    output.write(contenido.toByteArray())
                }
                Toast.makeText(this@MainActivity, "Exportado a: ${archivo.absolutePath}", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Error al exportar", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
