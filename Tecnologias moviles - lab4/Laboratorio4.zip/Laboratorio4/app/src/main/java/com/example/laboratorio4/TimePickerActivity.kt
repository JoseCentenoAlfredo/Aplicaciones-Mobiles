package com.example.laboratorio4

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TimePicker
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class TimePickerActivity : AppCompatActivity() {
    private lateinit var timePicker: TimePicker

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_time_picker)

        timePicker = findViewById(R.id.timePicker)
        timePicker.setIs24HourView(true)

        findViewById<Button>(R.id.btnGoToMain).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnGoToDateTimePicker).setOnClickListener {
            val intent = Intent(this, DateTimePickerActivity::class.java)
            startActivity(intent)
        }
    }

    fun onClick(view: View) {
        val hour = timePicker.hour
        val minute = timePicker.minute
        Toast.makeText(
            baseContext,
            "Hora seleccionada $hour:$minute",
            Toast.LENGTH_SHORT
        ).show()
    }
}
