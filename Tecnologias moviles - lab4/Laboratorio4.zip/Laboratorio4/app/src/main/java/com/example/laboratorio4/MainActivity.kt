package com.example.laboratorio4

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val presidents = arrayOf(
        "José Luis Bustamante",
        "Zenón Noriega",
        "Manuel Odriá",
        "Manuel Prado",
        "Fco Morales Bermúdez",
        "Fernando Belaunde",
        "Alberto Fujimori",
        "Valentín Paniagua",
        "Alejandro Toledo",
        "Alan García",
        "Pedro Pablo Kuczynski",
        "Martín Alberto Vizcarra",
        "Pedro Castillo Terrones",
        "Dina Boluarte Zegarra",
        "Jose Jeri Ore"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_dropdown_item_1line,
            presidents
        )
        val textView = findViewById<AutoCompleteTextView>(R.id.txtPresidentes)
        textView.threshold = 1
        textView.setAdapter(adapter)

        val btnGoToTimePicker = findViewById<Button>(R.id.btnGoToTimePicker)
        btnGoToTimePicker.setOnClickListener {
            val intent = Intent(this, TimePickerActivity::class.java)
            startActivity(intent)
        }

        val btnGoToDateTimePicker = findViewById<Button>(R.id.btnGoToDateTimePicker)
        btnGoToDateTimePicker.setOnClickListener {
            val intent = Intent(this, DateTimePickerActivity::class.java)
            startActivity(intent)
        }
    }
}
