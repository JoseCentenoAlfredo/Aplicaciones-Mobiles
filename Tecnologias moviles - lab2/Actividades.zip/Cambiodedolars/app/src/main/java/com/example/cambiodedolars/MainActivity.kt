package com.example.cambiodedolars

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editTextCantidad: EditText
    private lateinit var radioDolares: RadioButton
    private lateinit var radioSoles: RadioButton
    private val tipoCambio = 3.415f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextCantidad = findViewById(R.id.editTextText)
        radioDolares = findViewById(R.id.radio0)
        radioSoles = findViewById(R.id.radio1)
    }

    private fun convertirMoneda() {
        val cantidadTexto = editTextCantidad.text.toString().trim()

        if (cantidadTexto.isEmpty()) {
            mostrarError("Ingresa una cantidad")
            return
        }

        val cantidad = cantidadTexto.toFloatOrNull()
        if (cantidad == null || cantidad <= 0) {
            mostrarError("Ingresa un número válido mayor a 0")
            return
        }

        when {
            radioDolares.isChecked -> {
                val soles = cantidad * tipoCambio
                mostrarResultado("%.2f dólares = %.2f soles".format(cantidad, soles))

                // Cambiar selección para la próxima conversión
                radioDolares.isChecked = false
                radioSoles.isChecked = true
            }

            radioSoles.isChecked -> {
                val dolares = cantidad / tipoCambio
                mostrarResultado("%.2f soles = %.2f dólares".format(cantidad, dolares))

                // Cambiar selección para la próxima conversión
                radioSoles.isChecked = false
                radioDolares.isChecked = true
            }

            else -> {
                mostrarError("Selecciona una moneda")
            }
        }
    }

    fun miClicManejador(view: View) {
        if (view.id == R.id.btnConvertir) {
            convertirMoneda()
        }
    }

    private fun mostrarError(mensaje: String) {
        Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show()
        editTextCantidad.requestFocus()
    }

    private fun mostrarResultado(mensaje: String) {
        Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show()
    }
}
