package com.example.cambiodedolars

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editTextCantidad: EditText
    private lateinit var spinnerFrom: Spinner
    private lateinit var spinnerTo: Spinner
    private lateinit var btnConvertir: Button
    private lateinit var textViewResultado: TextView

    private val exchangeRatesToUsd = mapOf(
        "Dólar (EE.UU.)" to 1.0,
        "Nuevo Sol (Perú)" to 0.27,
        "Euro (Europa)" to 1.08,
        "Libra (Inglaterra)" to 1.26,
        "Rupia (India)" to 0.012,
        "Real (Brasil)" to 0.20,
        "Peso (México)" to 0.059,
        "Yuan (China)" to 0.14,
        "Yen (Japón)" to 0.0066
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextCantidad = findViewById(R.id.editTextCantidad)
        spinnerFrom = findViewById(R.id.spinnerFrom)
        spinnerTo = findViewById(R.id.spinnerTo)
        btnConvertir = findViewById(R.id.btnConvertir)
        textViewResultado = findViewById(R.id.textViewResultado)

        btnConvertir.setOnClickListener {
            convertirMoneda()
        }
    }

    private fun convertirMoneda() {
        val cantidadTexto = editTextCantidad.text.toString().trim()

        if (cantidadTexto.isEmpty()) {
            mostrarError("Ingresa una cantidad")
            return
        }

        val cantidad = cantidadTexto.toDoubleOrNull()
        if (cantidad == null || cantidad <= 0) {
            mostrarError("Ingresa un número válido mayor a 0")
            return
        }

        val fromCurrency = spinnerFrom.selectedItem.toString()
        val toCurrency = spinnerTo.selectedItem.toString()

        val rateFrom = exchangeRatesToUsd[fromCurrency] ?: 1.0
        val rateTo = exchangeRatesToUsd[toCurrency] ?: 1.0

        val resultado = (cantidad * rateFrom) / rateTo

        mostrarResultado("%.2f %s = %.2f %s".format(cantidad, fromCurrency, resultado, toCurrency))
    }

    private fun mostrarError(mensaje: String) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show()
        editTextCantidad.requestFocus()
    }

    private fun mostrarResultado(mensaje: String) {
        textViewResultado.text = mensaje
    }
}
