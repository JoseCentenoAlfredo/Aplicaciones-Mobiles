package com.example.myapplication

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val gridView = findViewById<GridView>(R.id.gridView)

        val pizzas = listOf(
            Pizza("Margarita", R.drawable.ic_launcher_background),
            Pizza("Pepperoni", R.drawable.ic_launcher_background),
            Pizza("Hawaiana", R.drawable.ic_launcher_background),
            Pizza("Cuatro Quesos", R.drawable.ic_launcher_background),
            Pizza("Vegetariana", R.drawable.ic_launcher_background),
            Pizza("BBQ Pollo", R.drawable.ic_launcher_background)
        )

        val adapter = PizzaAdapter(this, pizzas)
        gridView.adapter = adapter

        gridView.setOnItemClickListener { _, _, position, _ ->
            val selectedPizza = pizzas[position]
            Toast.makeText(this, "Has seleccionado: ${selectedPizza.name}", Toast.LENGTH_SHORT).show()
        }
    }

    data class Pizza(val name: String, val imageResId: Int)

    class PizzaAdapter(private val context: Context, private val pizzas: List<Pizza>) : BaseAdapter() {
        override fun getCount(): Int = pizzas.size
        override fun getItem(position: Int): Any = pizzas[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.grid_item, parent, false)
            val pizza = pizzas[position]

            val imageView = view.findViewById<ImageView>(R.id.pizzaImage)
            val textView = view.findViewById<TextView>(R.id.pizzaName)

            imageView.setImageResource(pizza.imageResId)
            textView.text = pizza.name

            return view
        }
    }
}
