package com.ucsm.lab9actvidades

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class PushNotificationService : FirebaseMessagingService() {

    companion object {
        const val TAG = "PushNotification"
        const val CHANNEL_ID = "fcm_channel"
        const val CHANNEL_NAME = "Notificaciones FCM"
    }

    // Se llama cuando llega un mensaje (app en primer plano o datos puros)
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "Mensaje recibido de: ${remoteMessage.from}")

        // Mensaje tipo notificación
        remoteMessage.notification?.let {
            Log.d(TAG, "Título: ${it.title} | Cuerpo: ${it.body}")
            mostrarNotificacion(it.title ?: "Sin título", it.body ?: "Sin contenido")
        }

        // Mensaje tipo datos (key-value)
        if (remoteMessage.data.isNotEmpty()) {
            Log.d(TAG, "Datos recibidos: ${remoteMessage.data}")
            val titulo = remoteMessage.data["titulo"] ?: "Mensaje nuevo"
            val cuerpo = remoteMessage.data["cuerpo"] ?: ""
            mostrarNotificacion(titulo, cuerpo)
        }
    }

    // Se llama cuando Firebase genera o renueva el token del dispositivo
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "Nuevo token FCM: $token")
        // Aquí puedes enviar el token a tu servidor si lo necesitas
    }

    private fun mostrarNotificacion(titulo: String, cuerpo: String) {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )

        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Canal obligatorio para Android 8+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(titulo)
            .setContentText(cuerpo)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
