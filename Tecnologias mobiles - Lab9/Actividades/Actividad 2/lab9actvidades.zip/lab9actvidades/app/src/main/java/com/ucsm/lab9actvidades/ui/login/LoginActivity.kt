package com.ucsm.lab9actvidades.ui.login

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.ucsm.lab9actvidades.MainActivity
import com.ucsm.lab9actvidades.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var mAuth: FirebaseAuth
    private lateinit var binding: ActivityLoginBinding

    private var semail: String = ""
    private var spassword: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mAuth = FirebaseAuth.getInstance()

        if (mAuth.currentUser != null) {
            goToMain()
            return
        }

        binding.login.setOnClickListener {
            binding.loading.visibility = View.VISIBLE
            performLoginOrRegistration()
        }
    }

    private fun performLoginOrRegistration() {
        semail = binding.username.text.toString().trim()
        spassword = binding.password.text.toString().trim()

        if (!Patterns.EMAIL_ADDRESS.matcher(semail).matches()) {
            binding.username.error = "Formato inválido de email"
            binding.loading.visibility = View.GONE
        } else if (TextUtils.isEmpty(spassword) || spassword.length < 6) {
            binding.password.error = "El password debe tener al menos 6 caracteres"
            binding.loading.visibility = View.GONE
        } else {
            loginUser()
        }
    }

    private fun loginUser() {
        mAuth.signInWithEmailAndPassword(semail, spassword)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    binding.loading.visibility = View.GONE
                    Toast.makeText(this, "Login exitoso: $semail", Toast.LENGTH_SHORT).show()
                    goToMain()
                } else {
                    registerUser()
                }
            }
    }

    private fun registerUser() {
        mAuth.createUserWithEmailAndPassword(semail, spassword)
            .addOnCompleteListener(this) { task ->
                binding.loading.visibility = View.GONE
                if (task.isSuccessful) {
                    Toast.makeText(this, "Registro exitoso: $semail", Toast.LENGTH_SHORT).show()
                    goToMain()
                } else {
                    Toast.makeText(
                        this,
                        "Error: ${task.exception?.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
    }

    private fun goToMain() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}