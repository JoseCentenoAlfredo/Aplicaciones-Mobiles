package com.ucsm.lab9actvidades

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessaging
import com.ucsm.lab9actvidades.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mAuth = FirebaseAuth.getInstance()

        // Mostrar el email del usuario autenticado
        val usuario = mAuth.currentUser
        binding.tvUsuario.text = "Usuario: ${usuario?.email ?: "No autenticado"}"

        // Obtener el token FCM del dispositivo
        obtenerTokenFCM()

        // Botón cerrar sesión
        binding.btnLogout.setOnClickListener {
            mAuth.signOut()
            Toast.makeText(this, "Sesión cerrada", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun obtenerTokenFCM() {
        FirebaseMessaging.getInstance().token
            .addOnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.w("FCM", "Error al obtener token", task.exception)
                    return@addOnCompleteListener
                }
                val token = task.result
                Log.d("FCM", "Token del dispositivo: $token")

                // Mostrar token en pantalla para copiarlo y hacer pruebas
                binding.tvToken.text = "Token FCM:\n$token"
                Toast.makeText(this, "Token obtenido. Ver logs.", Toast.LENGTH_SHORT).show()
            }
    }
}
