package com.ucsm.ejerciciolab08

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ucsm.ejerciciolab08.databinding.ItemEstudianteBinding

class EstudianteAdapter(
    private var list: List<Estudiante>,
    private val onEdit: (Estudiante) -> Unit,
    private val onDelete: (Estudiante) -> Unit
) : RecyclerView.Adapter<EstudianteAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemEstudianteBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemEstudianteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val estudiante = list[position]
        holder.binding.apply {
            tvNombre.text = estudiante.nombre
            tvCarrera.text = estudiante.carrera
            tvCurso.text = estudiante.curso
            
            btnEdit.setOnClickListener { onEdit(estudiante) }
            btnDelete.setOnClickListener { onDelete(estudiante) }
        }
    }

    override fun getItemCount(): Int = list.size

    fun updateList(newList: List<Estudiante>) {
        list = newList
        notifyDataSetChanged()
    }
}
