package com.ucsm.ejerciciolab08

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.database.*
import com.ucsm.ejerciciolab08.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var database: DatabaseReference
    private lateinit var adapter: EstudianteAdapter
    private var estudianteIdSeleccionado: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inicializar Firebase
        database = FirebaseDatabase.getInstance().getReference("estudiantes")

        setupRecyclerView()
        setupListeners()
        leerEstudiantes()
    }

    private fun setupRecyclerView() {
        adapter = EstudianteAdapter(
            list = emptyList(),
            onEdit = { estudiante ->
                // Llenar campos para editar
                binding.etNombre.setText(estudiante.nombre)
                binding.etCarrera.setText(estudiante.carrera)
                binding.etCurso.setText(estudiante.curso)
                estudianteIdSeleccionado = estudiante.id
                binding.btnGuardar.text = "Actualizar"
            },
            onDelete = { estudiante ->
                estudiante.id?.let { id ->
                    database.child(id).removeValue()
                        .addOnSuccessListener {
                            Toast.makeText(this, "Eliminado", Toast.LENGTH_SHORT).show()
                        }
                }
            }
        )
        binding.rvEstudiantes.layoutManager = LinearLayoutManager(this)
        binding.rvEstudiantes.adapter = adapter
    }

    private fun setupListeners() {
        binding.btnGuardar.setOnClickListener {
            val nombre = binding.etNombre.text.toString()
            val carrera = binding.etCarrera.text.toString()
            val curso = binding.etCurso.text.toString()

            if (nombre.isNotEmpty() && carrera.isNotEmpty() && curso.isNotEmpty()) {
                if (estudianteIdSeleccionado == null) {
                    // Crear nuevo
                    val id = database.push().key ?: return@setOnClickListener
                    val estudiante = Estudiante(id, nombre, carrera, curso)
                    database.child(id).setValue(estudiante)
                } else {
                    // Actualizar existente
                    val updates = mapOf(
                        "nombre" to nombre,
                        "carrera" to carrera,
                        "curso" to curso
                    )
                    database.child(estudianteIdSeleccionado!!).updateChildren(updates)
                    
                    // Resetear estado
                    estudianteIdSeleccionado = null
                    binding.btnGuardar.text = "Guardar"
                }
                limpiarCampos()
            } else {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun leerEstudiantes() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val lista = mutableListOf<Estudiante>()
                for (data in snapshot.children) {
                    val estudiante = data.getValue(Estudiante::class.java)
                    estudiante?.let { lista.add(it) }
                }
                adapter.updateList(lista)
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MainActivity, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun limpiarCampos() {
        binding.etNombre.text?.clear()
        binding.etCarrera.text?.clear()
        binding.etCurso.text?.clear()
    }
}
