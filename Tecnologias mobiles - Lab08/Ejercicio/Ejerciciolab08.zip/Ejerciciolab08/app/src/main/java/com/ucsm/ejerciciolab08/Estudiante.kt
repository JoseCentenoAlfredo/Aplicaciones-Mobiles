package com.ucsm.ejerciciolab08

data class Estudiante(
    val id: String? = null,
    val nombre: String? = "",
    val carrera: String? = "",
    val curso: String? = ""
)
