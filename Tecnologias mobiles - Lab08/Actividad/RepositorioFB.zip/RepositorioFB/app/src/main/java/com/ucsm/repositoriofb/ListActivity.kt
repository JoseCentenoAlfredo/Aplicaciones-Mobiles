package com.ucsm.repositoriofb

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class ListActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private val displayList = mutableListOf<String>()
    private lateinit var databaseReference: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        listView = findViewById(R.id.listViewClases)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, displayList)
        listView.adapter = adapter

        databaseReference = FirebaseDatabase.getInstance().getReference("Clases").child("Lecciones")

        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                displayList.clear()
                for (postSnapshot in snapshot.children) {
                    val clase = postSnapshot.getValue(Clase::class.java)
                    if (clase != null) {
                        // Formato simple para el ListView
                        val texto = "Sección: ${clase.seccion}\nAsignatura: ${clase.area}\nTema: ${clase.tema}"
                        displayList.add(texto)
                    }
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@ListActivity, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
