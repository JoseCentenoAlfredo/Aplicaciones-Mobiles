package com.ucsm.repositoriofb

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ClaseAdapter(private val claseList: List<Clase>) : RecyclerView.Adapter<ClaseAdapter.ClaseViewHolder>() {

    class ClaseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvSeccion: TextView = itemView.findViewById(R.id.tvSeccion)
        val tvArea: TextView = itemView.findViewById(R.id.tvArea)
        val tvTema: TextView = itemView.findViewById(R.id.tvTema)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ClaseViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_clase, parent, false)
        return ClaseViewHolder(view)
    }

    override fun onBindViewHolder(holder: ClaseViewHolder, position: Int) {
        val clase = claseList[position]
        holder.tvSeccion.text = "Sección: ${clase.seccion}"
        holder.tvArea.text = "Asignatura: ${clase.area}"
        holder.tvTema.text = "Tema: ${clase.tema}"
    }

    override fun getItemCount(): Int = claseList.size
}
